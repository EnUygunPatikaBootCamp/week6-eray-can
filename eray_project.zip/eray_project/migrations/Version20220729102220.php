<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20220729102220 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE product ADD product_name VARCHAR(255) DEFAULT NULL, ADD product_desc VARCHAR(255) DEFAULT NULL, ADD productp_piece INT DEFAULT NULL, ADD product_price INT DEFAULT NULL, ADD product_created_add DATETIME DEFAULT NULL, DROP productname, DROP productdesc, DROP productpiece, DROP productprice');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE product ADD productname VARCHAR(255) NOT NULL, ADD productdesc VARCHAR(255) NOT NULL, ADD productpiece INT NOT NULL, ADD productprice INT NOT NULL, DROP product_name, DROP product_desc, DROP productp_piece, DROP product_price, DROP product_created_add');
    }
}
