<?php

namespace App\Controller;

use App\Entity\Product;
use DateTime;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ProductController extends AbstractController
{

    /**
     * @Route("/product", name="add_product", methods={"POST"})
     */
    public function add(ManagerRegistry $doctrine): Response
    {
        $time = new DateTime();
        $time->format('H:i:s \O\n Y-m-d');

        $entitiyManager =$doctrine->getManager();
        $product = new Product();

        $product->setProductName("asadad    sd liste")
        ->setProductpPiece(1)
        ->setProductPrice(14)
        ->setProductCreatedAdd($time)
        ->setProductDesc("POST methodu ile eklendim");

        $entitiyManager->persist($product);
        $entitiyManager->flush();

        return new Response("asdas");

    }

    /**
     * @Route("/product/{id}", name="remove_product", methods={"DELETE"})
     */
    public function remove(ManagerRegistry $doctrine,int $id): Response
    {


        $entitiyManager =$doctrine->getManager();
        $product = $entitiyManager->getRepository(Product::class)->find($id);

        $entitiyManager->remove($product);
        $entitiyManager->flush();

        return new Response("asdas");

    }

    /**
     * @Route("/product/{id}", name="put_product", methods={"PUT"})
     */
    public function update(ManagerRegistry $doctrine,int $id): Response
    {
        $time = new DateTime();
        $time->format('H:i:s \O\n Y-m-d');

        $entitiyManager =$doctrine->getManager();
        $product = $entitiyManager->getRepository(Product::class)->find($id);

        if (!$product){

            $error=[
                'status'=>'Bad Requests',
            ];
            return new JsonResponse($error);

        }
        $error=[
            'status'=>'Successful Requests',
        ];


        $product->setProductName("yeniliste")
            ->setProductpPiece(3162)
            ->setProductPrice(6231)
            ->setProductCreatedAdd($time)
            ->setProductDesc("Put methodu ile güncelendim");


        $entitiyManager->flush();
        return new JsonResponse($error);
    }

    /**
     * @Route("/product/{id}", name="main_product", methods={"GET"})
     */
    public function idlist( ManagerRegistry $doctrine,$id): Response
    {



            $entitiyManager =$doctrine->getManager();
            $product = $entitiyManager->getRepository(Product::class)->find($id);

            if (!$product){

                $error=[
                    'status'=>'Bad Requests',
                ];
                return new JsonResponse($error);

            }

            $data[] = [
                'status'=>'Successful Requests',
                'data'=> [
                    'id' => $product->getId(),
                    'name' => $product->getProductName(),
                    'piece' => $product->getProductpPiece(),
                    'price' => $product->getProductPrice(),
                    'description' => $product->getProductDesc(),
                ]

            ];

            $entitiyManager->flush();

            return new JsonResponse($data);


    }

    /**
     * @Route("/product", name="gett_product", methods={"GET"})
     */
    public function alllist(ManagerRegistry $doctrin): Response
    {
        $Manager=$doctrin->getManager();
        $product=$Manager->getRepository(Product::class)->findAll();



        foreach($product as $e)
        {
            $data[] = [
                'id' => $e->getId(),
                'name' => $e->getProductName(),
                'piece' => $e->getProductpPiece(),
                'price' => $e->getProductPrice(),
                'description' => $e->getProductDesc(),
            ];


        }
        return new JsonResponse($data);



    }

}
