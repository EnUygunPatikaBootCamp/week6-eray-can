<?php

namespace App\Entity;

use App\Repository\ProductRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ProductRepository::class)]
class Product
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $productName = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $ProductDesc = null;

    #[ORM\Column(nullable: true)]
    private ?int $productpPiece = null;

    #[ORM\Column(nullable: true)]
    private ?int $productPrice = null;

    #[ORM\Column(type: Types::DATETIME_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $productCreatedAdd = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getProductName(): ?string
    {
        return $this->productName;
    }

    public function setProductName(?string $productName): self
    {
        $this->productName = $productName;

        return $this;
    }

    public function getProductDesc(): ?string
    {
        return $this->ProductDesc;
    }

    public function setProductDesc(?string $ProductDesc): self
    {
        $this->ProductDesc = $ProductDesc;

        return $this;
    }

    public function getProductpPiece(): ?int
    {
        return $this->productpPiece;
    }

    public function setProductpPiece(?int $productpPiece): self
    {
        $this->productpPiece = $productpPiece;

        return $this;
    }

    public function getProductPrice(): ?int
    {
        return $this->productPrice;
    }

    public function setProductPrice(?int $productPrice): self
    {
        $this->productPrice = $productPrice;

        return $this;
    }

    public function getProductCreatedAdd(): ?\DateTimeInterface
    {
        return $this->productCreatedAdd;
    }

    public function setProductCreatedAdd(?\DateTimeInterface $productCreatedAdd): self
    {
        $this->productCreatedAdd = $productCreatedAdd;

        return $this;
    }
}
